
export default async function Page() {

  return (
    <>
    <h1 className="">Home page</h1>
    </>
  )
}
