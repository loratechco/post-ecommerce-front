import Skeleton from "./components/Skeleton";

// app/dashboard/loading.tsx
export default function Loading() {
  return <Skeleton />;
}
