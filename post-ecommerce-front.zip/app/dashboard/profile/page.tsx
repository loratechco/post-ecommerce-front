import TabsListProfile from "../components/tab-profile/TabsList";
function Profile() {

    return (
        <>
            <TabsListProfile />
        </>
    );
}

export default Profile;