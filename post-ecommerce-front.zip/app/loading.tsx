import { LucideLoader2 } from "lucide-react";

export default function Loading() {
  return (
    <>
      <section className="h-screen w-full bg-red-50 centerize-flex">
        <LucideLoader2
          width={60}
          height={60}
          className="animate-spin text-primary-color text-sm"
        />
      </section>
    </>
  );
}
