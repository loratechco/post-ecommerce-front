function Loading() {
    return (

        <section className="h-full w-full flex items-center justify-center">
            <span className="loading loading-ring loading-lg scale-150"></span>
        </section>
    );
}

export default Loading;